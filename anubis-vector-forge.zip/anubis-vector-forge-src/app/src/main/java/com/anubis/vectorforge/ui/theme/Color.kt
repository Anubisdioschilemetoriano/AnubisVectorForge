package com.anubis.vectorforge.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFD4A017)
val GoldVariant = Color(0xFFB8860B)
val GoldContainer = Color(0xFF3D2C00)
val OnGoldContainer = Color(0xFFFFE0A0)

val DeepPurple = Color(0xFF1A0A2E)
val SurfaceDark = Color(0xFF120820)
val SurfaceVariantDark = Color(0xFF2A1A40)

val ErrorRed = Color(0xFFCF6679)
val ErrorContainer = Color(0xFF3B0014)
val OnErrorContainer = Color(0xFFFFB3C1)

val OnSurface = Color(0xFFEDE8FF)
val OnSurfaceVariant = Color(0xFFBDB0CC)

val LightPrimary = Color(0xFF7B4F00)
val LightPrimaryContainer = Color(0xFFFFDEA0)
val LightBackground = Color(0xFFFFF8F0)
val LightSurface = Color(0xFFFFF8F0)
