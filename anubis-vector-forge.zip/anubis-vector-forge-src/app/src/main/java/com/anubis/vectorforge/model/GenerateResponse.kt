package com.anubis.vectorforge.model

import com.google.gson.annotations.SerializedName

/**
 * Response from the backend image-generation endpoint.
 *
 * Two conventions are supported — adapt to match yours:
 *  1. imageUrl      — backend returns a URL to the generated image
 *  2. imageBase64   — backend returns the image as a Base64-encoded string
 *
 * If your backend returns something different, update this class and
 * ImageRepository accordingly.
 */
data class GenerateResponse(
    @SerializedName("image_url")
    val imageUrl: String? = null,
    @SerializedName("image_base64")
    val imageBase64: String? = null,
    @SerializedName("message")
    val message: String? = null,
    @SerializedName("error")
    val error: String? = null
)
