package com.anubis.vectorforge.data.api

import com.anubis.vectorforge.model.GenerateRequest
import com.anubis.vectorforge.model.GenerateResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Retrofit interface for your image-generation backend.
 *
 * Endpoint: POST /generate
 * Change the path to match your actual backend route.
 */
interface ImageGenerationApi {

    @POST("generate")
    suspend fun generateImage(
        @Body request: GenerateRequest
    ): Response<GenerateResponse>
}
