package com.anubis.vectorforge

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.anubis.vectorforge.ui.screen.AppNavHost
import com.anubis.vectorforge.ui.theme.AnubisVectorForgeTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AnubisVectorForgeTheme {
                AppNavHost()
            }
        }
    }
}
