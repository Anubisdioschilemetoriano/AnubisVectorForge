package com.anubis.vectorforge.data.repository

import com.anubis.vectorforge.data.api.ImageGenerationApi
import com.anubis.vectorforge.model.GenerateRequest
import com.anubis.vectorforge.model.GenerationResult
import javax.inject.Inject
import javax.inject.Singleton

sealed class RepositoryResult<out T> {
    data class Success<T>(val data: T) : RepositoryResult<T>()
    data class Error(val message: String) : RepositoryResult<Nothing>()
}

@Singleton
class ImageRepository @Inject constructor(
    private val api: ImageGenerationApi
) {
    suspend fun generateImage(
        prompt: String,
        negativePrompt: String = "",
        steps: Int = 20,
        width: Int = 512,
        height: Int = 512
    ): RepositoryResult<GenerationResult> {
        return try {
            val request = GenerateRequest(
                prompt = prompt,
                negativePrompt = negativePrompt,
                steps = steps,
                width = width,
                height = height
            )
            val response = api.generateImage(request)

            if (response.isSuccessful) {
                val body = response.body()
                if (body != null) {
                    if (body.error != null) {
                        RepositoryResult.Error(body.error)
                    } else {
                        RepositoryResult.Success(
                            GenerationResult(
                                prompt = prompt,
                                imageUrl = body.imageUrl,
                                imageBase64 = body.imageBase64
                            )
                        )
                    }
                } else {
                    RepositoryResult.Error("Empty response body")
                }
            } else {
                RepositoryResult.Error("Server error: ${response.code()} ${response.message()}")
            }
        } catch (e: Exception) {
            RepositoryResult.Error(e.localizedMessage ?: "Unknown network error")
        }
    }
}
