package com.anubis.vectorforge.model

import com.google.gson.annotations.SerializedName

/**
 * Response from the backend's image-generation endpoint.
 *
 * Two common backend conventions are supported — adapt to match yours:
 *  1. imageUrl  — the backend returns a URL to the generated image
 *  2. imageBase64 — the backend returns the image as a Base64-encoded string
 *
 * If your backend returns something different, update this class and
 * [com.anubis.vectorforge.data.repository.ImageRepository] accordingly.
 */
data class GenerateResponse(
    @SerializedName("image_url")
    val imageUrl: String? = null,
    @SerializedName("image_base64")
    val imageBase64: String? = null,
    @SerializedName("message")
    val message: String? = null,
    @SerializedName("error")
    val error: String? = null
)
