package com.anubis.vectorforge.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anubis.vectorforge.data.repository.ImageRepository
import com.anubis.vectorforge.data.repository.RepositoryResult
import com.anubis.vectorforge.model.GenerationResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class GenerateUiState {
    data object Idle : GenerateUiState()
    data object Loading : GenerateUiState()
    data class Success(val result: GenerationResult) : GenerateUiState()
    data class Error(val message: String) : GenerateUiState()
}

@HiltViewModel
class GenerateViewModel @Inject constructor(
    private val repository: ImageRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<GenerateUiState>(GenerateUiState.Idle)
    val uiState: StateFlow<GenerateUiState> = _uiState.asStateFlow()

    private val _prompt = MutableStateFlow("")
    val prompt: StateFlow<String> = _prompt.asStateFlow()

    private val _negativePrompt = MutableStateFlow("")
    val negativePrompt: StateFlow<String> = _negativePrompt.asStateFlow()

    private val _steps = MutableStateFlow(20)
    val steps: StateFlow<Int> = _steps.asStateFlow()

    fun onPromptChange(value: String) {
        _prompt.value = value
    }

    fun onNegativePromptChange(value: String) {
        _negativePrompt.value = value
    }

    fun onStepsChange(value: Int) {
        _steps.value = value.coerceIn(1, 150)
    }

    fun generate() {
        val currentPrompt = _prompt.value.trim()
        if (currentPrompt.isBlank()) {
            _uiState.value = GenerateUiState.Error("Prompt cannot be empty")
            return
        }

        viewModelScope.launch {
            _uiState.value = GenerateUiState.Loading
            val result = repository.generateImage(
                prompt = currentPrompt,
                negativePrompt = _negativePrompt.value.trim(),
                steps = _steps.value
            )
            _uiState.value = when (result) {
                is RepositoryResult.Success -> GenerateUiState.Success(result.data)
                is RepositoryResult.Error -> GenerateUiState.Error(result.message)
            }
        }
    }

    fun reset() {
        _uiState.value = GenerateUiState.Idle
    }
}
