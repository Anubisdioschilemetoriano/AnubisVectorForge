package com.anubis.vectorforge.model

/**
 * Domain model for a completed image generation.
 * Decoupled from the raw API response.
 */
data class GenerationResult(
    val prompt: String,
    val imageUrl: String?,
    val imageBase64: String?
)
