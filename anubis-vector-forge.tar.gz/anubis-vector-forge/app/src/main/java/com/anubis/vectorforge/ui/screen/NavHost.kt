package com.anubis.vectorforge.ui.screen

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

object Routes {
    const val HOME = "home"
    const val RESULT = "result"
}

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            GenerateScreen(navController = navController)
        }
        composable(Routes.RESULT) {
            ResultScreen(navController = navController)
        }
    }
}
