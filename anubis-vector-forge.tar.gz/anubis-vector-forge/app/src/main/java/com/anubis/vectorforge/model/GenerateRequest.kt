package com.anubis.vectorforge.model

import com.google.gson.annotations.SerializedName

data class GenerateRequest(
    @SerializedName("prompt")
    val prompt: String,
    @SerializedName("negative_prompt")
    val negativePrompt: String = "",
    @SerializedName("steps")
    val steps: Int = 20,
    @SerializedName("width")
    val width: Int = 512,
    @SerializedName("height")
    val height: Int = 512
)
