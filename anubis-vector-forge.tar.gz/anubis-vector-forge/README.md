# Anubis Vector Forge — Android App

A Kotlin + Jetpack Compose Android app that sends text prompts to your own image-generation backend and displays the results.

## Architecture

```
MVVM + Clean Architecture (single-module)
│
├── model/               Domain models (request, response, result)
├── data/
│   ├── api/             Retrofit interface (ImageGenerationApi)
│   └── repository/      ImageRepository — maps API ↔ domain
├── di/                  Hilt dependency injection (NetworkModule)
└── ui/
    ├── theme/           Material 3 dark/light theme (gold + deep purple)
    ├── viewmodel/       GenerateViewModel (StateFlow, sealed UiState)
    └── screen/          GenerateScreen, ResultScreen, NavHost
```

## Tech Stack

| Library | Purpose |
|---|---|
| Jetpack Compose (BOM 2024.08) | UI |
| Material 3 | Design system |
| Hilt 2.51.1 | Dependency injection |
| Retrofit 2.11 + Gson | HTTP client / JSON |
| OkHttp 4.12 | HTTP + logging interceptor |
| Coil 2.7 | Async image loading (URL) |
| Navigation Compose | Screen navigation |
| Kotlin Coroutines | Async operations |

## Setup

### 1. Point to your backend

Open `app/build.gradle.kts` and update `BASE_URL`:

```kotlin
buildConfigField("String", "BASE_URL", "\"https://your-backend.example.com/\"")
```

For a local backend on the Android emulator, use `http://10.0.2.2:<port>/`.

### 2. Match your API contract

The app calls `POST /generate` with this JSON body:

```json
{
  "prompt": "string",
  "negative_prompt": "string",
  "steps": 20,
  "width": 512,
  "height": 512
}
```

And expects one of these response shapes:

```json
{ "image_url": "https://..." }
```

or

```json
{ "image_base64": "iVBORw0KGgo..." }
```

To change the endpoint path or request/response fields, edit:
- `data/api/ImageGenerationApi.kt` — endpoint path and HTTP method
- `model/GenerateRequest.kt` — request fields
- `model/GenerateResponse.kt` — response fields

### 3. Build & Run

Open the project in **Android Studio Ladybug (2024.2+)** and run on an emulator or device with API 26+.

```bash
./gradlew assembleDebug
```

## Customisation

- **Add auth headers** — inject an `Interceptor` in `NetworkModule.kt` that appends `Authorization: Bearer <token>`
- **History screen** — add a `Room` database, store `GenerationResult` entities, add a history ViewModel + screen
- **Save to gallery** — use `MediaStore` API in the result screen to write the bitmap to the device gallery
- **Share** — add a share button using Android's `ShareCompat` in `ResultScreen.kt`
